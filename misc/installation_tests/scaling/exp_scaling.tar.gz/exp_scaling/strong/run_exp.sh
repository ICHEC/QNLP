#!/bin/bash
#SBATCH -J qubits_full
#SBATCH -N 8

#SBATCH -p ProdQ
#SBATCH -t 00:20:00
#SBATCH -A "ichec001"
#no extra settings

NQUBITS=28

NNODES=8
NPROCS=16
NTHREADS=20


module use /ichec/work/ichec001/Intel-QS/modules/:/ichec/work/ichec001/modules:/ichec/work/ichec001/modules/:/ichec/modules

#module load qhipster
module load intel
#module load bigmpi

export OMP_NUM_THREADS=${NTHREADS}
srun -N ${NNODES} -n ${NPROCS} -c ${NTHREADS} ../../src/exe_qft_test ${NQUBITS}

mv slurm-${SLURM_JOBID}.out slurm_${NQUBITS}_${NNODES}_${NPROCS}_${NTHREADS}.out
